module.exports = {
  secret: "1@2@3@secretkeyitis",
};
