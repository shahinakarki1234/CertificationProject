to setup mongodb in ubuntu

https://hevodata.com/blog/install-mongodb-on-ubuntu/
https://stackoverflow.com/questions/7948789/mongod-complains-that-there-is-no-data-db-folder
https://stackoverflow.com/questions/48092353/failed-to-start-mongod-service-unit-mongod-service-not-found
https://www.digitalocean.com/community/tutorials/how-to-install-mongodb-on-ubuntu-20-04

> sudo systemctl stop mongodb

> sudo systemctl restart mongodb

In two terminals
sudo mongod
mongo
